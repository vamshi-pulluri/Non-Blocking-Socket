package com.example.srinath.finalhangman;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

public class GameActivity
        extends AppCompatActivity
{
    private String ip;
    private int port;

    private Socket socket;
    private PrintWriter writer;

    private ThreadPoolExecutor executor;

    @InjectView(R.id.score_textview)
    TextView scoreTextView;

    @InjectView(R.id.guesses_left_textview)
    TextView guessesLeftTextView;

    @InjectView(R.id.message_textview)
    TextView messageTextView;

    @InjectView(R.id.current_word_textview)
    TextView currentWordTextView;

    @InjectView(R.id.guess_edittext)
    EditText guessEditText;

    @InjectView(R.id.failed_layout)
    LinearLayout failedView;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        ButterKnife.inject(this);

        ip = getIntent().getStringExtra("IP");
        port = getIntent().getIntExtra("PORT", 4444);
        Log.d("MYINT", "value: " + port);

        executor = new ThreadPoolExecutor(15, 25, 10000, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>());

        new ServerReceiverAsyncTask().executeOnExecutor(executor);

        guessEditText.setOnKeyListener(new View.OnKeyListener()
        {
            @Override
            public boolean onKey(View v,
                                 int keyCode,
                                 KeyEvent event)
            {
                if (keyCode == KeyEvent.KEYCODE_ENTER)
                {
                    sendGuess();
                }
                return true;
            }
        });
    }



    @Override
    protected void onDestroy()
    {
        super.onDestroy();

        if (socket != null)
        {
            try
            {
                socket.close();
            }
            catch (IOException e)
            {
                e.printStackTrace();

            }
        }
    }



    @OnClick(R.id.send_button)
    public void sendGuess()
    {
        String guess = guessEditText.getText().toString();

        if (guess != null && guess.isEmpty() == false)
        {
            new SendMessageAsyncTask(guess).executeOnExecutor(executor);
            guessEditText.setText("");
        }
    }



    @OnClick(R.id.new_game_button)
    public void startNewGame()
    {
        new SendMessageAsyncTask("start game").executeOnExecutor(executor);
    }



    @OnClick(R.id.failed_button)
    public void clickBackToLobby()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

        finish();
    }



    class SendMessageAsyncTask
            extends AsyncTask<Void, Void, Void>
    {
        private String message;



        public SendMessageAsyncTask(String message)
        {
            this.message = message;
        }



        @Override
        protected Void doInBackground(Void... params)
        {
            try
            {
                if (socket == null)
                {
                    socket = new Socket();
                    socket.connect(new InetSocketAddress(ip,port));
                    Log.d("connect","connected");
                }

                if (writer == null)
                {
                    writer = new PrintWriter(socket.getOutputStream());
                }

                writer.println(message);
                writer.flush();
            }
            catch (IOException e)
            {
                e.printStackTrace();

                runOnUiThread(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        failedView.setVisibility(View.VISIBLE);
                    }
                });
            }
            return null;
        }
    }


    class ServerReceiverAsyncTask
            extends AsyncTask<Void, Void, Void>
    {

        @Override
        protected Void doInBackground(Void... params)
        {
            try
            {
                if (socket == null)
                {
                    socket = new Socket();
                    socket.connect(new InetSocketAddress(ip,port));
                    Log.d("connect","connected");
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                String msg;

                while ((msg = reader.readLine()) != null)
                {
                    final String[] message = msg.split(",");

                    runOnUiThread(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            currentWordTextView.setText(message[0]);
                            messageTextView.setText(message[1]);
                            guessesLeftTextView.setText("Guesses left: " + message[2]);
                            scoreTextView.setText("Score: " + message[3]);
                        }
                    });
                }
            }
            catch (IOException e)
            {
                e.printStackTrace();

                runOnUiThread(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        failedView.setVisibility(View.VISIBLE);
                    }
                });
            }
            return null;
        }
    }
}